#include <stdlib.h>
#include <stdio.h>
#include "tree.h"
#include "symbol_table.h"
#include "output.h"

#define ON 1
#define OFF 0

extern int simp;
extern int ple;
extern unsigned int numple;
extern unsigned int numsimp;
extern unsigned int antiprenex;
extern unsigned int prenex;

extern symbol_table *st_index;
extern tree *get_nnf(tree *t, int polarity,int option);
extern tree *get_simp(tree *t, int polarity, int option);
extern tree *update_parent(tree *t);
extern unsigned int is_literal(tree *t);

int numprenex = 0;
int numaprenex = 0;

tree *replace_parent(tree *parent, tree *position) {
  if (parent->left == position) {
    parent->left = NULL;
    parent->right = delete_tree(parent->right);
    parent->children = delete_list(parent->children);
  }
  else if (parent->right == position) {
    parent->right = NULL;
    parent->left = delete_tree(parent->left);
    parent->children = delete_list(parent->children);
  }
  else {
    parent->left = delete_tree(parent->left);
    parent->right = delete_tree(parent->right);
    list *aux = parent->children;
    while (aux != NULL) {
      if (aux->child != position)
	aux->child = delete_tree(aux->child);
      list *aux2 = aux;
      aux = aux->next;
      free(aux2);
    }
    parent->children = NULL;
  }
  position->parent = parent->parent;
  parent = copy_node(parent,position);
  position->left = NULL;
  position->right = NULL;
  position->children = NULL;
  position = delete_tree(position);
  parent = update_parent(parent);
  return parent;
}

tree *get_prenex(tree *node) {

  if (node == NULL)
    return NULL;
  //  printf("\n prenex: \n");print_tree(node); getchar();
  switch (node->op) {
  case CONSTANT:
  case PROP:
    break;
  case NEXT:
  case ALWAYS:
  case SOMETIME:
      {
	node->left = get_prenex(node->left);
	node->index = hash_tree(node);
      }
      break;
  case NOT:
      {
	if (is_literal(node))
	  return node;
	else printf("\n Error. Prenex. Negation.");
      }
      break;
  case UNTIL:
  case UNLESS:
    {
      node->left = get_prenex(node->left);
      node->right = get_prenex(node->right);
      if (node->left->op == NEXT && node->right->op == NEXT) {
	node->left = replace_parent(node->left,node->left->left);
	node->right = replace_parent(node->right,node->right->left);
	tree *new = create_tree(node->op,node->left,node->right,NULL);
	new->parent = node;
	node->op = NEXT;
	node->left = new;
	node->right = NULL;
      }
    }
    break;
  case AND:
    {
      sort_formulalist(AND,&(node->children));
      list *aux = node->children;
      while (aux != NULL) { 
	aux->child = get_prenex(aux->child);
	if (aux->child->op == AND) {
	  if (aux->child->children == NULL) {
	    aux->child->op = CONSTANT;
	    aux->child->index = CTRUE;
	    aux->child->left = NULL;
	    aux->child->right = NULL;
	    aux->child->children = NULL;
	    aux->child->index = hash_tree(aux->child);
	    symbol_table *p = find_prop(aux->child->index);
	    p = insert_constant_position(p,aux->child);
	  }
	  else {
	    list *aux2 = aux->child->children;
	    list *aux3 = aux->child->children;
	    while (aux3->next != NULL) {
	      aux3 = aux3->next;
	    }
	    aux3->next = aux->next;
	    free(aux->child);
	    aux->child = aux2->child;
	    aux->next = aux2->next;
	    free(aux2);
	    aux = aux3;
	  }
	}
	  aux = aux->next;
      }

      sort_formulalist(AND,&(node->children));
      node->children->index = hash_list(node->children);
      node->index = hash_tree(node);
	
      aux = node->children;
      while (aux != NULL && aux->child->op != ALWAYS)
	aux = aux->next;
      
      while (aux != NULL && aux->child->op == ALWAYS) {
	list *first = aux;
	list *last = aux;
	while (last->next != NULL && (last->next->child->op == ALWAYS)) {
	  last = last->next;
	}

	if (first != last) {
	  numprenex++;
	  list *newfirst = malloc(sizeof(list));
	  if (!newfirst) {printf("Out of Memory\n"); exit(1);}
	  newfirst->child = first->child;
	  newfirst->index = first->index;
	  newfirst->next = first->next;
	  
	  list *aux = newfirst;
	  
	  while (aux != last->next) {
	    tree *auxnode = aux->child;
	    aux->child = aux->child->left;
	    aux = aux->next;
	    free(auxnode); // this is only freeing the box;
	  }

	  first->next = last->next;
	  last->next = NULL;
	    
	  tree *and = create_tree(AND,NULL,NULL,newfirst);
	  and = get_prenex(and);
	  tree *box = create_tree(ALWAYS,and,NULL,NULL);
	  box = update_parent(box);
	  box->parent = node;

	  first->child = box;
	  
	}
	aux = aux->next;
      }

      aux = node->children;
      
      unsigned int op = UNTIL;
      unsigned int nextop = UNLESS;
      
    redo_and:
      sort_formulalist(AND,&(node->children));
      node->children->index = hash_list(node->children);
      node->index = hash_tree(node);

      while (aux != NULL && aux->child->op != op)
	aux = aux->next;
      while (aux != NULL && aux->child->op == op) {
	list *next = aux->next;
	list *and = malloc(sizeof(list));
	if (!and) {printf("Out of Memory\n"); exit(1);}
	and->child = copy_tree(aux->child->left,1);
	and->next = NULL;

	list *pred = aux;
	while (next != NULL && next->child->op == op) { 
	  if (same_tree(aux->child->right,next->child->right)) {
	    list *new = malloc(sizeof(list));
	    if (!new) {printf("Out of Memory\n"); exit(1);}
	    new->child = copy_tree(next->child->left,1);
	    new->next = and;
	    and = new;
	    pred->next = next->next;
	    next->child = delete_tree(next->child);
	    list *tmp = next;
	    next = next->next;
	    free(tmp);
	  }
	  else {
	    pred = next;
	    next = next->next;
	  }
	}

	if (and->next == NULL) {
	  and->child = delete_tree(and->child);
	  free(and);
	}
	else {
	  numprenex++;
	  aux->child->left->op = AND;
	  sort_formulalist(AND,&and);
	  aux->child->left->children = and;
	  aux->child->left->left = NULL;
	  aux->child->left->right = NULL;
	  aux->child->left->index = hash_tree(aux->child->left);
	  aux->child->index = hash_tree(aux->child);
	  node->index = hash_tree(node);
	}

	aux = aux->next;
      }

      if (op != nextop) {
	op = nextop;
	goto redo_and;
      }
      
      if (node->children->next == NULL) {// this is a list of size 1;
	node = replace_parent(node,node->children->child);
      }
	
      if (node->children != NULL) {
	sort_formulalist(AND,&(node->children));
	node->children->index = hash_list(node->children);
      }
      node->index = hash_tree(node);
    }
    break;
  case OR:
    {
      sort_formulalist(OR,&(node->children));
      list *aux = node->children;
      while (aux != NULL) { 
	aux->child = get_prenex(aux->child);
	if (aux->child->op == OR) {
	  if (aux->child->children == NULL) {
	    aux->child->op = CONSTANT;
	    aux->child->index = CFALSE;
	    aux->child->left = NULL;
	    aux->child->right = NULL;
	    aux->child->children = NULL;
	    aux->child->index = hash_tree(aux->child);
	    symbol_table *p = find_prop(aux->child->index);
	    p = insert_constant_position(p,aux->child);
	  }
	  else {
	    list *aux2 = aux->child->children;
	    list *aux3 = aux->child->children;
	    while (aux3->next != NULL) {
	      aux3 = aux3->next;
	    }
	    aux3->next = aux->next;
	    free(aux->child);
	    aux->child = aux2->child;
	    aux->next = aux2->next;
	    free(aux2);
	    aux = aux3;
	  }
	}
	aux = aux->next;
      }

      sort_formulalist(OR,&(node->children));
      node->children->index = hash_list(node->children);
      node->index = hash_tree(node);

      aux = node->children;
      while (aux != NULL && aux->child->op != SOMETIME)
	aux = aux->next;
	
      while (aux != NULL && aux->child->op == SOMETIME) {
	list *first = aux;
	list *last = aux;
	while (last->next != NULL && last->next->child->op == SOMETIME) {
	  last = last->next;
	}

	if (first != last) {
	  numprenex++;
	  list *newfirst = malloc(sizeof(list));
	  if (!newfirst) {printf("Out of Memory\n"); exit(1);}
	  newfirst->child = first->child;
	  newfirst->index = first->index;
	  newfirst->next = first->next;
	    
	  list *aux = newfirst;
	  
	  while (aux != last->next) {
	    tree *auxnode = aux->child;
	    aux->child = aux->child->left;
	    aux = aux->next;
	    free(auxnode); // this is only freeing the diamond;
	  }
	  
	  first->next = last->next;
	  last->next = NULL;
	    
	  tree *or = create_tree(OR,NULL,NULL,newfirst);
	  or = get_prenex(or);
	  tree *diamond = create_tree(SOMETIME,or,NULL,NULL);
	  diamond = update_parent(diamond);
	  diamond->parent = node;
	  first->child = diamond;
	}
	aux = aux->next;
      }

      aux = node->children;
      
      unsigned int op = UNTIL;
      unsigned int nextop = UNLESS;

    redo_or:
      sort_formulalist(OR,&(node->children));
      node->children->index = hash_list(node->children);
      node->index = hash_tree(node);

      while (aux != NULL && aux->child->op != op)
	aux = aux->next;
      while (aux != NULL && aux->child->op == op) {
	list *next = aux->next;
	list *or = malloc(sizeof(list));
	if (!or) {printf("Out of Memory\n"); exit(1);}
	or->child = copy_tree(aux->child->right,1);
	or->next = NULL;

	list *pred = aux;
	while (next != NULL && next->child->op == op) { 
	  if (same_tree(aux->child->left,next->child->left)) {
	    list *new = malloc(sizeof(list));
	    if (!new) {printf("Out of Memory\n"); exit(1);}
	    new->child = copy_tree(next->child->right,1);
	    new->next = or;
	    or = new;
	    pred->next = next->next;
	    next->child = delete_tree(next->child);
	    list *tmp = next;
	    next = next->next;
	    free(tmp);
	  }
	  else {
	    pred = next;
	    next = next->next;
	  }
	}

	if (or->next == NULL) {
	  or->child = delete_tree(or->child);
	  free(or);
	}
	else {
	  numprenex++;
	  aux->child->right->op = OR;
	  sort_formulalist(OR,&or);
	  aux->child->right->children = or;
	  aux->child->right->left = NULL;
	  aux->child->right->right = NULL;
	  aux->child->right->index = hash_tree(aux->child->right);
	  aux->child->index = hash_tree(aux->child);
	  node->index = hash_tree(node);
	}

	aux = aux->next;
      }

      if (op != nextop) {
	op = nextop;
	goto redo_or;
      }

      if (node->children->next == NULL) {// this is a list of size 1;
	node = replace_parent(node,node->children->child);
      }
      
      if (node->children != NULL) {
	sort_formulalist(OR,&(node->children));
	node->children->index = hash_list(node->children);
      }
      node->index = hash_tree(node);
     }
    break;
  default:
    {
      printf("\n Unknown Operator. In prenex. node->op, node->index, node: %d, %d, %p",node->op,node->index,node);
      //	  getchar();
    }
  }
    if (node != NULL) {
    node = update_parent(node);
    node->index = hash_tree(node);
  }
  return node;
}

tree *get_antiprenex(tree *node) {
  if (node != NULL) {
    switch (node->op) {
    case PROP:
    case CONSTANT:
    case NOT:
      break;
    case NEXT:
      {
	node->left = get_antiprenex(node->left);
	if (node->left->op == OR || node->left->op == AND) {
	  list *aux = node->left->children;
	  while (aux != NULL) {
	    tree *new = create_tree(NEXT,aux->child,NULL,NULL);
	    new->index = hash_tree(new);
	    new->parent = node->parent;
	    aux->child = new;
	    aux = aux->next;
	  }
	  node->op = node->left->op;
	  node->children = node->left->children;
	  free(node->left);
	  node->left = NULL;
	  numprenex++;
	  node = get_antiprenex(node);
	}
	else if (node->left->op == ALWAYS || node->left->op == SOMETIME) {
	  node->op = node->left->op;
	  node->left->op = NEXT;
	  node->left->index = hash_tree(node->left);
	  node->index = hash_tree(node);
	  numprenex++;
	  node = get_antiprenex(node);
	}
	else if (node->left->op == UNTIL || node->left->op == UNLESS) {
	  tree *new = create_tree(NEXT,node->left->left,NULL,NULL);
	  node->left->left = new;
	  new->parent = node->left;
	  
	  new = create_tree(NEXT,node->left->right,NULL,NULL);
	  node->left->right = new;
	  new->parent = node->left;

	  node = replace_parent(node,node->left);
	  numprenex++;
	  node = get_antiprenex(node);
	}
      }
      break;
    case SOMETIME:
      {
	node->left = get_antiprenex(node->left);
	if (node->left->op == OR) {
	  list *aux = node->left->children;
	  while (aux != NULL) {
	    tree *new = create_tree(node->op,aux->child,NULL,NULL);
	    new->index = hash_tree(new);
	    new->parent = node->parent;
	    aux->child = new;
	    aux = aux->next;
	  }
	  node->op = node->left->op;
	  node->children = node->left->children;
	  free(node->left);
	  node->left = NULL;
	  numprenex++;
	  node = get_antiprenex(node);
	}
      }
      break;
    case ALWAYS:
      {
	node->left = get_antiprenex(node->left);
	if (node->left->op == AND) {
	  list *aux = node->left->children;
	  while (aux != NULL) {
	    tree *new = create_tree(node->op,aux->child,NULL,NULL);
	    new->index = hash_tree(new);
	    new->parent = node->parent;
	    aux->child = new;
	    aux = aux->next;
	  }
	  node->op = node->left->op;
	  node->children = node->left->children;
	  free(node->left);
	  node->left = NULL;
	  numprenex++;
	  node = get_antiprenex(node);
	}
      }
      break;
    case UNTIL:
    case UNLESS:
      {
	node->left = get_antiprenex(node->left);
	node->right = get_antiprenex(node->right);
	if (node->left->op == AND) {
	  list *aux = node->left->children;
	  while (aux != NULL) {
	    tree *right = copy_tree(node->right,1);
	    tree *new = create_tree(node->op,aux->child,right,NULL);
	    new->index = hash_tree(new);
	    new->parent = node->parent;
	    aux->child = new;
	    aux = aux->next;
	  }
	  node->op = node->left->op;
	  node->children = node->left->children;
	  free(node->left);
	  node->left = NULL;
	  node->right = delete_tree(node->right);
	  numprenex++;
	  node = get_antiprenex(node);
	}
	else if (node->right->op == OR) {
	  list *aux = node->right->children;
	  while (aux != NULL) {
	    tree *left = copy_tree(node->left,1);
	    tree *new = create_tree(node->op,left,aux->child,NULL);
	    new->index = hash_tree(new);
	    new->parent = node->parent;
	    aux->child = new;
	    aux = aux->next;
	  }
	  node->op = node->right->op;
	  node->children = node->right->children;
	  free(node->right);
	  node->right = NULL;
	  node->left = delete_tree(node->left);
	  numprenex++;
	  node = get_antiprenex(node);
	}
      }
      break;
    case AND:
    case OR:
      {
	list *aux = node->children;
	while (aux != NULL) {
	  aux->child = get_antiprenex(aux->child);
	  aux = aux->next;
	}
      }
      break;
    default:
      printf("Unknown operator, antiprenex, op: %u", node->op);
    }
  }
  if (node != NULL) {
    node = update_parent(node);
    node->index = hash_tree(node);
  }
  return node;
}

void do_truth_propagation(tree **node, tree **parent_node);
void do_falsity_propagation(tree **node, tree **parent_node) {
  tree *parent = *parent_node;
  tree *t = *node;
  if (t != NULL && parent != NULL) {
    switch(parent->op) {
    case NOT:
      {
	parent->left = delete_tree(parent->left);
	parent->op = CONSTANT;
	parent->index = CTRUE;
	symbol_table *entry = find_prop(parent->index);
	entry = insert_constant_position(entry,parent);
	do_truth_propagation(&parent,&(parent->parent));
	numsimp++;
      }
      break;
    case OR:
      {
	sort_formulalist(OR,&(parent->children));
	list *tmp = parent->children;
	if (tmp->child == t && tmp->next == NULL) {
	  parent->children = NULL;
	  parent = replace_parent(parent,t);
	  do_falsity_propagation(&parent,&(parent->parent));
	  numsimp++;
	}
	else if (tmp->child == t && tmp->next != NULL) { // false | phi = phi
	  parent->children = parent->children->next;
	  tmp->child = delete_tree(tmp->child);
	  numsimp++;
	}
	tmp = parent->children;
	if (tmp != NULL && tmp->next == NULL) {
	  parent->children = NULL;
	  parent = replace_parent(parent,tmp->child);
	  numsimp++;
	}
      }
      break;
    case IMPLY:
      {
	if (t == parent->left) { //false then phi = true
	  parent->left = delete_tree(parent->left);
	  parent->op = CONSTANT;
	  parent->index = CTRUE;
	  symbol_table *entry = find_prop(parent->index);
	  entry = insert_constant_position(entry,parent);
	  do_truth_propagation(&parent,&(parent->parent));
	  numsimp++;
	}
	else { // phi => false = not phi.
	  parent->right = delete_tree(parent->right);
	  parent->left = create_tree(NOT,parent->left,NULL,NULL);
	  parent = replace_parent(parent,parent->left);
	  numsimp++;
	}	
      }
      break;
    case NEXT:
    case SOMETIME:
    case ALWAYS:
    case AND:
      {
	parent = replace_parent(parent,t);
	do_falsity_propagation(&parent,&(parent->parent));
	numsimp++;
      }
      break;
    case UNTIL:
      {
	if (parent->right == t) {
	  parent = replace_parent(parent,t);
	  do_falsity_propagation(&parent,&(parent->parent));
	  numsimp++;
	}
	else if (parent->left == t) {
	  parent->left = delete_tree(parent->left);
	  parent = replace_parent(parent,parent->right);
	  numsimp++;
	}
      }
      break;
    case UNLESS:
      {
	if (parent->right == t) {
	  parent->op = ALWAYS;
	  parent->right = delete_tree(parent->right);
	  numsimp++;
	}
	else if (parent->left == t) {
	  parent->left = delete_tree(parent->left);
	  parent = replace_parent(parent,parent->right);
	  numsimp++;
	}
      }      
      break;
    default:
      printf("\n Unknow operator: falsity propagation, %p, %u",parent,parent->op);
      break;
    }
  }
}

void do_truth_propagation(tree **node, tree **parent_node) {
  tree *parent = *parent_node;
  tree *t = *node;
  if (t != NULL && parent != NULL) {
    switch(parent->op) {
    case NOT:
      {
	parent->left = delete_tree(parent->left);
	parent->op = CONSTANT;
	parent->index = CFALSE;
	symbol_table *entry = find_prop(parent->index);
	entry = insert_constant_position(entry,parent);
	do_falsity_propagation(&parent,&(parent->parent));
	numsimp++;
      }
      break;
    case AND:
      {
	sort_formulalist(AND,&(parent->children));
	list *tmp = parent->children;
	if (tmp->child == t && tmp->next == NULL) {
	  parent->children = NULL;
	  parent = replace_parent(parent,t);
	  do_truth_propagation(&parent,&(parent->parent));
	  numsimp++;
	}
	else if (tmp->child == t && tmp->next != NULL) { // true & phi = phi
	  parent->children = parent->children->next;
	  tmp->child = delete_tree(tmp->child);
	  numsimp++;
	}
	tmp = parent->children;
	if (tmp != NULL && tmp->next == NULL) {
	  parent->children = NULL;
	  parent = replace_parent(parent,tmp->child);
	  numsimp++;
	}
      }
      break;
    case IMPLY:
      {
	if (t == parent->left) { // true is on the left-hand side: true => phi = phi
	  parent->left = delete_tree(parent->left);
	  parent = replace_parent(parent,parent->right);
	  numsimp++;
	}
	else { // true is on the right-hand side of the implication phi => true = true
	  parent = replace_parent(parent,t);
	  do_truth_propagation(&parent,&(parent->parent));
	  numsimp++;
	}	
      }
      break;
    case NEXT:
    case SOMETIME:
    case ALWAYS:
    case UNLESS:
    case OR:
      {
	//	printf("\n Truth propagation, parent %p, parent->op %u",parent,parent->op);
	parent = replace_parent(parent,t);
	do_truth_propagation(&parent,&(parent->parent));
	numsimp++;
      }
      break;
    case UNTIL:
      {
	if (parent->right == t) {
	  parent = replace_parent(parent,t);
	  do_truth_propagation(&parent,&(parent->parent));
	  numsimp++;
	}
	else if (parent->left == t) {
	  t = delete_tree(t);
	  parent->op = SOMETIME;
	  parent->left = parent->right;
	  parent->right = NULL;
	  numsimp++;
	}
      }
      break;
    default:
      printf("\n Unknow operator: truth propagation, %p, %u",parent,parent->op);
      break;
    }
  }
}

void do_constant_propagation(void) {
  symbol_table *current = find_prop(CTRUE);
  if (current != NULL) {
    positions *p = current->constants;
    while (p != NULL) {
      if (p->pos != NULL) {
	tree *t = p->pos;
	do_truth_propagation(&t,&(t->parent));
	print_out("TRUTH PROPAGATION");
      }
      p = p->next;
    }
  }

  current = find_prop(CFALSE);
  if (current != NULL) {
    positions *p = current->constants;
    while (p != NULL) {
      if (p->pos != NULL) {
	tree *t = p->pos;
	do_falsity_propagation(&t,&(t->parent));
	print_out("FALSITY PROPAGATION");
      }
      p = p->next;
    }
  }
}

void do_ple(void) {
  symbol_table *current = NULL,*tmp = NULL;
  positions *props = NULL;
  int constant = 0;
  HASH_ITER(hh_index,st_index,current,tmp) {
    if (current->positive_occurrences == 0 && current->negative_occurrences != 0) {
      constant = CFALSE;
      props = current->negative;
      current->negative = NULL;
    }
    else if (current->positive_occurrences != 0 && current->negative_occurrences == 0) {
      constant = CTRUE;
      props = current->positive;
      current->positive = NULL;
    }
    if (props != NULL) {
      while (props != NULL) {
	tree *t = props->pos;
	t->op = CONSTANT;
	t->index = constant;
	symbol_table *entry = find_prop(constant);
	if (entry != NULL)
	  entry = insert_constant_position(entry,t);
	else {
	  if (constant == CTRUE)
	    t->index = st_InsertEntry("true");
	  else 	t->index = st_InsertEntry("false");
	  t->index = constant;
	  symbol_table *entry = find_prop(constant);
	  entry = insert_constant_position(entry,t);
	}
	current->occurrences--;
	positions *tmp = props;
	props = props->next;
	free(tmp);
	numple++;
      }
      if (constant)
	current->positive_occurrences = 0;
      else
	current->negative_occurrences = 0;
    }
  }
}


tree *linearise(tree *s, int polarity) {
  if (s != NULL) {
    s->polarity = polarity;
    if (s->op == PROP) {
      symbol_table *entry = find_prop(s->index);
      //      entry->occurrences++;
      if (polarity > 0) {
	entry = insert_prop_position(POSITIVE,entry,s);
      }
      else if (polarity < 0) {
  	entry = insert_prop_position(NEGATIVE,entry,s);
      }
    }
    else if (s->op == CONSTANT) {
      symbol_table *entry = find_prop(s->index);
      entry = insert_constant_position(entry,s);
    }
    else if (s->op == IFF) {
      if (polarity > 0) { // (p iff q) = (p then q) and (q then p)
	tree *left = copy_tree(s->left,0);
	tree *right = copy_tree(s->right,0);
	tree *ifpart = create_tree(IMPLY,s->left,s->right,NULL);
	ifpart->parent = s;
	tree *onlyifpart = create_tree(IMPLY,right,left,NULL);
	onlyifpart->parent = s;
	s->op = AND;
	s->children = tree_to_list(ifpart,onlyifpart,AND);
	s->left = NULL;
	s->right = NULL;
	sort_formulalist(AND,&(s->children));
	s->index = hash_tree(s);
	s = linearise(s,polarity);
	return s;
      }
      else { // (p iff q) = (p & q) | (~p & ~q)
	tree *newleft = copy_tree(s->left,0);
	tree *newright = copy_tree(s->right,0);
	list *leftlist = tree_to_list(s->left,s->right,AND);
	tree *left = create_tree(AND,NULL,NULL,leftlist);
	left->parent = s;
	tree *notleft = create_tree(NOT,newleft,NULL,NULL);
	tree *notright = create_tree(NOT,newright,NULL,NULL);
	list *rightlist = tree_to_list(notleft,notright,AND);
	tree *right = create_tree(AND,NULL,NULL,rightlist);
	right->parent = s;

	s->op = OR;
	s->left = NULL;
	s->right = NULL;
	s->children = tree_to_list(left,right,OR);
	sort_formulalist(OR,&(s->children));
	s->index = hash_tree(s);
	s = linearise(s,polarity);
	return s;
      }
    }
    else if (s->op == NOT || s->op == IMPLY)
      s->left = linearise(s->left,-polarity);
    else
      s->left = linearise(s->left,polarity);
    
    s->right = linearise(s->right,polarity);

    list *aux = s->children;
    while (aux != NULL) {
      aux->child = linearise(aux->child,polarity);
      aux = aux->next;
    }
  }
  return s;
}

tree *input_preprocessing (tree *root) {

  unsigned int oldsimp;

  int flag = 1;
  if (ple || simp) {
    do {
      oldsimp = numsimp;
      if (ple) {
	do_ple();
	print_out("PLE");
      }
      do_constant_propagation();
      print_out("CONSTANT PROPAGATION");
      if (simp) {
	if (flag) {
	  root = get_nnf(root,1,0);
	  print_out("NNF");
	  root = get_simp(root,1,0);
	  print_out("SIMPLIFICATION");
	  do_constant_propagation();
	  print_out("CONSTANT PROPAGATION");
	  if (antiprenex == ON) {
	    root = get_antiprenex(root);
	    print_out("ANTIPRENEX");
	    root = get_simp(root,1,0);
	    print_out("SIMPLIFICATION");
	    do_constant_propagation();
	    print_out("CONSTANT PROPAGATION");
	  }
	  int oldnumprenex;
	  do {
	    oldnumprenex = numprenex;
	    if (prenex == ON) {
	      root = get_prenex(root);
	      print_out("PRENEX");
	      root = get_simp(root,1,0);
	      print_out("SIMPLIFICATION");
	      do_constant_propagation();
	      print_out("CONSTANT PROPAGATION");
	    }
	  } while (numprenex > oldnumprenex);
	  flag = 0;
	}
	root = get_simp(root,1,0);
	print_out("SIMPLIFICATION");
	do_constant_propagation();
	print_out("CONSTANT PROPAGATION");
      }
    } while (numsimp > oldsimp);
  }
  if (flag) {
    root = get_nnf(root,1,0);
    print_out("NNF");
    if (antiprenex == ON) {
      root = get_antiprenex(root);
      print_out("ANTIPRENEX");
    }
    int oldnumprenex;
    do {
      oldnumprenex = numprenex;
      if (prenex == ON) {
	root = get_prenex(root);
	print_out("PRENEX");
      }
    } while (numprenex > oldnumprenex);
    flag = 0;
  }
  return root;
}
