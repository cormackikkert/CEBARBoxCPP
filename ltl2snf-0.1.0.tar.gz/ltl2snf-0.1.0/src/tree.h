#define NOT 261
#define AND 262
#define OR 263
#define IMPLY 264
#define IFF 265
#define ONLYIF 266
#define NEXT 267
#define ALWAYS 268
#define SOMETIME 269
#define UNTIL 270
#define UNLESS 271

#define CONSTANT 0
#define PROP 1

#define CTRUE 0
#define CFALSE 1
#define CSTART 2

#define POSITIVE 1
#define NEGATIVE -1

typedef struct tree tree;
typedef struct list list;

/* singly linked list */
/* the empty list is represted by the null pointer */

struct list {
  unsigned int index;
  unsigned int renamed_by;
  unsigned int definition_added;
  tree *child;
  tree *parent;
  list *next;
};

/* string tree */
/* No, we won't keep a copy of the string for every occurrence of a prop/cte symbol */

struct tree {
  unsigned int op;
  unsigned int index;
  int polarity;
  unsigned int renamed_by;
  unsigned int definition_added;
  tree *left;
  tree *right;
  list *children;
  tree *parent;
};

/* my functions */
list *tree_to_list(tree *t1, tree *t2, unsigned int op);
tree* new_tree(void);
tree* tree_op(tree *t, unsigned int op);
tree* tree_children(tree *t, tree *left, tree *right, list *children);
int same_tree (tree *t1, tree *t2);
int print_tree(tree *s);
tree* create_tree(unsigned int op, tree *left, tree *right, list *children);
tree* delete_tree(tree *t);
list *delete_list(list *l);
void sort_formulalist(int type, list **l);
tree *copy_tree(tree *s, int option);
tree *copy_node(tree *s1, tree *s2);

unsigned int hash_list (list *l);
unsigned int hash_tree (tree *t);
