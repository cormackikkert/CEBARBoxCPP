#include <stdio.h>
#include "symbol_table.h"
#include "tree.h"

extern tree *update_parent(tree *t);
extern tree *replace_parent(tree *parent, tree *position);
extern list *flatten(list *s, int op);

int neg_op (int op) {
  if (op == NEXT)
    return NEXT;
  if (op == ALWAYS)
    return SOMETIME;
  if (op == SOMETIME)
    return ALWAYS;
  if (op == OR)
    return AND;
  if (op == AND)
    return OR;
  if (op == UNTIL)
    return UNLESS;
  if (op == UNLESS)
    return UNTIL;
  return 0;
}

tree *get_nnf(tree *s, int polarity, int stat) {
  if (s == NULL)
    return NULL;
  s->polarity = polarity;
  switch (s->op) {
  case CONSTANT:
  case PROP:
    break;
  case ALWAYS:
  case SOMETIME:
    {
      s->left = get_nnf(s->left,polarity,stat);
    }
    break;
  case NEXT:
    {
      if (s->left->op == OR) {
	list *aux = s->left->children;
	while (aux != NULL) {
	  tree *newnext = create_tree(NEXT,aux->child,NULL,NULL);
	  newnext->index = hash_tree(newnext);
	  newnext->parent = s->parent;
	  aux->child = newnext;
	  aux = aux->next;
	}
	s->op = OR;
	s->children = s->left->children;
	free(s->left);
	s->left = NULL;
	s = get_nnf(s,polarity,stat);
      }
      else
	s->left = get_nnf(s->left,polarity,stat);
    }
    break;
  case UNTIL:
  case UNLESS:
    {
      s->left = get_nnf(s->left,polarity,stat);
      s->right = get_nnf(s->right,polarity,stat);
    }
    break;
  case IMPLY:
    {
      s->left = create_tree(NOT,s->left,NULL,NULL);
      s->left->parent = s;
      s->children = tree_to_list(s->left,s->right,OR);
      s->op = OR;
      s->left = NULL;
      s->right = NULL;
      s = get_nnf(s,polarity,stat);
    }
    break;
  case AND:
  case OR:
    {
      list *aux = s->children;
      //      int flag = 0;
      while (aux != NULL) {
	aux->child = get_nnf(aux->child,polarity,stat);
	//	if (aux->child->op == s->op)
	//	  flag = 1;
	aux = aux->next;
      }
      /*      if (flag) {
	s->children = flatten(s->children,s->op);
	s = update_parent(s);
	} */
    }
    break;
  case NOT:
    {
      if (s->left->op == NOT) {
	tree *aux = s->left->left;
	aux->parent = s->parent;
	s->left->left = NULL;
	s = delete_tree(s);
	s = aux;
	s = get_nnf(s,polarity,stat);
      }
      else if (s->left->op == CONSTANT) {
	s->op = CONSTANT;
	if (s->left->index == CTRUE)
	  s->index = CFALSE;
	else s->index = CTRUE;
	s->left = delete_tree(s->left);
	symbol_table *entry = find_prop(s->index);
	entry = insert_constant_position(entry,s);
	s = get_nnf(s,polarity,stat);
      }
      else if (s->left->op == ALWAYS || s->left->op == SOMETIME || s->left->op == NEXT) {
	s->op = neg_op(s->left->op);
	s->left->op = NOT;
	s->left->index = hash_tree(s->left);
	s = get_nnf(s,polarity,stat);
      }
      else if (s->left->op == AND || s->left->op == OR) {
	s->op = neg_op(s->left->op);
	list *aux = s->left->children;
	aux->parent = s;
	while (aux != NULL) {
	  aux->child = create_tree(NOT,aux->child,NULL,NULL);
	  aux->child->parent = s;
	  aux = aux->next;
	}
	s->children = s->left->children;
	free(s->left);
	s->left = NULL;
	s = get_nnf(s,polarity,stat);
      }
      else if (s->left->op == UNTIL || s->left->op == UNLESS) {
	tree *left = create_tree(NOT,s->left->right,NULL,NULL);
	left->parent = s->left;
	left->polarity = s->left->polarity;
	left->left->polarity = NEGATIVE;
	tree *not_left = copy_tree(left,1);
	tree *not_right = create_tree(NOT,s->left->left,NULL,NULL);
	list *land = tree_to_list(not_left,not_right,AND);
	tree *and = create_tree(AND,NULL,NULL,land);
	land->parent = s->left;
	not_right->parent = and;
	not_left->parent = and;
	and->parent = s->left;
	s->op = neg_op(s->left->op);
	free(s->left);
	s->left = left;
	s->right = and;
	s = get_nnf(s,polarity,stat);
      }
      else if (s->left->op == IMPLY) {
	s->left->right = create_tree(NOT,s->left->right,NULL,NULL);
	s->children = tree_to_list(s->left->left,s->left->right,AND);
	free(s->left);
	s->left = NULL;
	s->op = AND;
	s = get_nnf(s,polarity,stat);
      }
      else s->left = get_nnf(s->left,-polarity,stat);
    }
    break;
  default:
    printf("\n Unknow Operator. In NNF. %u", s->op);
  }
  if (s != NULL) {
    s = update_parent(s);
    s->index = hash_tree(s);
  }
  return s;
}
