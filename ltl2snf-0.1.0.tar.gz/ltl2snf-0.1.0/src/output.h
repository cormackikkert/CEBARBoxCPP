void print_out (char *phase);
void print_short(int cycle);
void print_really_short(void);
void print_to_file(FILE *out, tree *s);
