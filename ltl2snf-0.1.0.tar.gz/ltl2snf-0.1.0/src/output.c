#include <stdio.h>
#include <string.h>
#include <time.h>
#include "symbol_table.h"
#include "tree.h"

extern unsigned int numerrors;
extern unsigned int numprops;
extern unsigned int numtemp;
extern unsigned int numsimp;
extern unsigned int numple;
extern unsigned int numpropsple;

extern unsigned int verbose;
extern unsigned int time_stamp;

extern tree *root;
extern void print_ren_hash(void);

char *op_name(unsigned int op) {
  if (op == NOT) return "not";
  else if (op == NEXT) return "next";
  else if (op == ALWAYS) return "always";
  else if (op == SOMETIME) return "sometime";
  else if (op == AND) return "and";
  else if (op == OR) return "or";
  else {
    printf("********** error ********** OP: %u",op);
    return "********** error **********";
  }
}

int print_to_file(FILE *out, tree *s) {
  int flag = 1;
  if (s != NULL) {
    if (s->op == ALWAYS && s->left->op == OR && s->left->children->child->op == CONSTANT && s->left->children->child->index == CTRUE){
      flag = 0;
    }
    else if (s->op == CONSTANT || s->op == PROP) {
      symbol_table *entry = find_prop(s->index);
      if (s->index >= numprops) {
	fprintf(out,"nnv%u",(entry->index) - numprops);
      }
      else
	fprintf(out,"%s",entry->name);
    }
    else if (s->op == NOT || s->op == NEXT || s->op == ALWAYS || s->op == SOMETIME) {
      fprintf(out,op_name(s->op));
      fprintf(out,"(");
      print_to_file(out,s->left);
      fprintf(out,")");
    }
    else {
      fprintf(out,op_name(s->op));
      fprintf(out,"([");
      list *aux = s->children;
      while (aux != NULL) {
	flag = print_to_file(out,aux->child);
	if (flag && aux->next != NULL) fprintf(out,",");
	flag = 1;
	aux = aux->next;
      }
      fprintf(out,"])");
    }
  }
  return flag;
}

void print_really_short(void) {
  printf("Stats: %u, %u, %u, %u, %u\n",numprops-3,numpropsple,numtemp-numprops,numple,numsimp);
}

void print_short(void) {
  printf("\n\n Statistics:\n");
  printf("\n Number of propositional symbols (original): %u", numprops-3);
  printf("\n Number of propositional symbols (after simplification): %u", numpropsple);
  if (numtemp >= numprops) 
    printf("\n Number of propositional symbols (introduced by renaming) %u", numtemp-numprops);
  printf("\n Number of simplification steps: %u", numsimp);
  printf("\n Occurrences of pure literals removed by early PLE: %u\n", numple);
}


void print_out (char *phase) {
  switch (verbose) {
  case 6:  {
    if (numerrors == 0) {
      printf("\n Starting %s",phase);
      printf("\n Syntactic Tree:\n");
      print_tree(root);
    }
  }
  case 5: {
    printf("\n Symbol Table:\n");
    st_Print();
  }
  case 4: {
    print_ren_hash();
  }
  case 3: {
    print_short();
  }
  case 2: {
    printf("\n Finished %s",phase);
    if (time_stamp) {
      time_t t;
      time(&t);
      char *s = ctime(&t);
      s[strlen(s) - 1] = '\0';
      printf(" %s",s);
    }
  }
  case 1: {
  }
  default:
    break;
  }
}


