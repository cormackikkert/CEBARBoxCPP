#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>

#include "symbol_table.h"
#include "tree.h"
#include "output.h"

#define ON 1
#define OFF 0

/* Global variables: statistics */

unsigned int numprops = 3; /*0 = true, 1 = false, 2 = start*/
unsigned int numtemp = 0;
unsigned int numsimp = 0;
unsigned int numclauses = 0;
unsigned int numple = 0;
unsigned int numpropsple = 0;

tree* root = NULL;

/* global variables for execution options */

unsigned int simp = OFF;
unsigned int ple = OFF;
unsigned int ruletracker = OFF;
unsigned int printsnf    = OFF;
unsigned int verbose = OFF;
unsigned int strong_renaming = OFF;
unsigned int reuse_renaming = OFF;
unsigned int normal_renaming = ON;
unsigned int time_stamp = OFF;
unsigned int improved_snf = OFF;
unsigned int snf = 1;  // For snf variants
unsigned int prenex = OFF;
unsigned int antiprenex = OFF;
unsigned int ppi_only = OFF;

extern FILE *yyin;
extern struct list *formula_list;
extern int yyparse(void);
extern int yy_scan_string(const char *);
extern int yylex_destroy();
extern int numerrors;

extern tree *input_preprocessing (tree *t);
extern tree *delete_tree(tree *t);
extern void stDelete(void);
extern void clean_ren_hash(void);
extern void print_ren_hash(void);

extern tree *linearise(tree *s, int polarity, int depth);
extern tree *get_nnf(tree *t,int depth, int polarity,int option);
extern tree *get_snf(tree *t);


int main(int argc, char** argv) {

  /* Yes, I am using all memory available */
  /* To be changed to a parameter passed in the command line */
  
  struct rlimit limits;
  getrlimit(RLIMIT_STACK,&limits);
  limits.rlim_cur = limits.rlim_max;
  setrlimit(RLIMIT_STACK,&limits);
  
  int i = 1;
  int fromfile = OFF;
  int tofile = OFF;

  FILE *outfile = NULL;
    
  while (i < argc){
    if(!strcmp(argv[i], "-ruletracker")) ruletracker = ON;
    else if (!strcmp(argv[i],"-i")) {
      yyin=fopen(argv[++i], "r");
      fromfile = ON;
      if (yyin == NULL) {
	printf("\n Input file not found: %s\n",argv[i]);
	return 1;
      }
    }
    else if (!strcmp(argv[i],"-o")) {
      outfile=fopen(argv[++i], "w");
      if (outfile == NULL) {
	printf("\n Unable to open output file: %s\n",argv[i]);
	return 1;
      }
      tofile = ON;
    }
    else if (!strcmp(argv[i],"-f")) {
      char *formula =  malloc(snprintf(NULL, 0, "%s", argv[++i]) + 1);
      if (!formula) {printf("Out of Memory\n"); exit(1);}
      sprintf(formula,"%s",argv[i]);
      yy_scan_string(formula);
      free(formula);
    }
    else if (!strcmp(argv[i], "-printsnf")){
      printsnf = ON;
    }
    else if (!strcmp(argv[i], "-ruletracker")){
      ruletracker = ON;
    }
    else if (!strcmp(argv[i], "-ple")){
      ple = ON;
    }
    else if (!strcmp(argv[i], "-simp")){
      simp = ON;
    }
    else if (!strcmp(argv[i], "-isnf")){
      improved_snf = ON;
    }
    else if (!strcmp(argv[i], "-prenex")){
      prenex = ON;
    }
    else if (!strcmp(argv[i], "-aprenex")){
      antiprenex = ON;
    }
    else if (!strcmp(argv[i],"-time_stamp")) {
      time_stamp = ON;
    }
    else if (!strcmp(argv[i],"-ppi_only")) {
      ppi_only = ON;
    }
    else if (!strcmp(argv[i], "-reuse_renaming")){
      normal_renaming = OFF; reuse_renaming = ON; strong_renaming = OFF;
    }
    else if (!strcmp(argv[i], "-strong_renaming")){
      normal_renaming = OFF; reuse_renaming = OFF; strong_renaming = ON;
    }
    else if (!strcmp(argv[i], "-v")) {
      verbose = atoi(argv[++i]);
    }
    else if (!strcmp(argv[i], "-snf")) {
      verbose = atoi(argv[++i]);
    }
    else {
      printf("\n Unknown flag: %s\n",argv[i]);
      return 1;
    }
    i++;
  }

  yyparse();
  if (yyin != NULL && fromfile == ON) fclose(yyin);
  yylex_destroy();
  print_out("Parsing");
  
  if (numerrors == 0) {
    root = linearise(root,1,0);
    print_out("Linearise");

    root = input_preprocessing(root);
    numpropsple = countprops();
    
    if (ppi_only) goto clean;
    
    numtemp = numprops+1;
    root = get_snf(root);
    print_out("SNF");

    if (tofile == ON) {
      print_to_file(outfile,root);
      fprintf(outfile,".");
      fclose(outfile);
      outfile = NULL;
    }
    
    if (verbose == 1) {
      print_really_short();
      exit(0);
    }
  }

 clean:
  // The following line is commented because there is some bug in the glibc-2.12-1.209.el6_9.2.x86_64 library, which is the one installed in our servers. Uncomment the line if you have a newer version of glibc. It works fine with glibc-2.26-27, for instance.
  //  if (tofile == ON && outfile != NULL) fclose(outfile);
  exit(0);
  root = delete_tree(root);
  clean_ren_hash();
  st_Delete();
  return 0;
}
