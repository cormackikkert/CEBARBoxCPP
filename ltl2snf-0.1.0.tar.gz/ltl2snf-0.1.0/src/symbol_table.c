#include <stdio.h>
#include <stdlib.h>
#include "uthash.h"
#include "tree.h"
#include "symbol_table.h"

extern unsigned int numprops;

struct symbol_table *st_name = NULL;
struct symbol_table *st_index = NULL;

/* Creation of a node for new propositional symbols */
/* Type is needed here so that we can get a nice ordering */


symbol_table *create_p_node (char* name, unsigned int id) {
  symbol_table *new = (symbol_table *) malloc(sizeof(symbol_table));
  if (new == NULL) {printf("Out of Memory\n"); exit(1);}
  new->name = name;
  new->index = id;
  new->occurrences = 1;
  new->positive_occurrences = 0;
  new->negative_occurrences = 0;
  new->constants = NULL;
  new->positive = NULL;
  new->negative = NULL;
  return new;
}

/* For symbols used in renaming, I'm storing the empty string and only using its index */

symbol_table *insert_pnew_node (unsigned int id) {
  symbol_table *p = NULL;
  char *s = NULL;
  p = create_p_node(s,id);
  HASH_ADD(hh_index,st_index,index,sizeof(unsigned int),p);
  return p;
}

positions *insert_positions(tree *t, positions *p) {
  positions *new = malloc(sizeof(positions));
  if (new == NULL) {printf("Out of Memory\n"); exit(1);}
  new->pos = t;
  new->next = p;
  return new;
}
			    
positions *free_positions(positions *p) {
  positions *next = NULL;
  while (p != NULL) {
    next = p->next;
    free(p);
    p = next;
  }
  return NULL;
}

unsigned int st_InsertEntry(char *name){
  symbol_table *entry = NULL;

  HASH_FIND(hh_id,st_name,name,strlen(name),entry);
  if(entry != NULL){
    if (!strcmp(name,entry->name)){
      entry->occurrences++;
    }
    else {
      printf("\n Colision\n");
      exit(0);
    }
  }
  else {
    char *id = strdup(name);
    entry = malloc(sizeof(symbol_table));
    if (entry == NULL) {printf("Out of Memory\n"); exit(1);}
    entry->name = id;
    entry->positive = NULL;
    entry->negative = NULL;
    entry->constants = NULL;
    entry->occurrences = 1;
    entry->positive_occurrences = 0;
    entry->negative_occurrences = 0;
    HASH_ADD_KEYPTR(hh_id,st_name,id,strlen(id),entry);
    if (!strcmp(name,"true"))
      entry->index = CTRUE;
    else if (!strcmp(name,"false"))
      entry->index = CFALSE;
    else entry->index = numprops++;
    HASH_ADD(hh_index,st_index,index,sizeof(unsigned int),entry);
  }
  return entry->index;
}

symbol_table *delete_prop_position(symbol_table *entry,void *s){
  positions *aux = NULL;
  entry->occurrences--;
  tree *t = s;
  if (t->polarity == POSITIVE) {
    aux = entry->positive;
    entry->positive_occurrences--;
    if (aux != NULL && aux->pos == s) {
      entry->positive = entry->positive->next;
      free(aux);
      aux = NULL;
    }
  }
  else {
    aux = entry->negative;
    entry->negative_occurrences--;
    if (aux != NULL && aux->pos == s) {
      entry->negative = entry->negative->next;
      free(aux);
      aux = NULL;
    }
  }
  if (aux != NULL) {
    while (aux->next != NULL && aux->next->pos != s)
      aux = aux->next;
    if (aux->next != NULL) {
      positions *tmp = aux->next;
      aux->next = aux->next->next;
      free(tmp);
    }
  }
  return entry;
}

symbol_table *insert_prop_position(int polarity, symbol_table *entry, void *s){
  positions *new = malloc(sizeof(positions));
  if (new == NULL) {printf("Out of Memory\n"); exit(1);}
  new->pos = s;
  if (polarity == POSITIVE) {
    new->next = entry->positive;
    entry->positive = new;
    entry->positive_occurrences++;
  }
  else {
    new->next = entry->negative;
    entry->negative = new;
    entry->negative_occurrences++;
  }
  return entry;
}

symbol_table *insert_constant_position(symbol_table *entry, void *s){
  if (entry == NULL) {
    tree *t = s;
    if (t->index == CTRUE)
      st_InsertEntry("true");
    else st_InsertEntry("false");
    entry = find_prop(t->index);
  }
  positions *new = malloc(sizeof(positions));
  if (new == NULL) {printf("Out of Memory\n"); exit(1);}
  new->pos = s;
  new->next = entry->constants;
  entry->constants = new;
  return entry;
}

symbol_table *find_prop(unsigned int index) {
  symbol_table *entry = NULL;  
  HASH_FIND(hh_index,st_index,&index,sizeof(unsigned int),entry);
  return entry;
}

void st_Print(void){
    symbol_table *it;

    for(it = st_index; it != NULL; it = it->hh_index.next){
      if (it->index != CTRUE && it->index != CFALSE) {
	printf(" Propositional symbol:");
	if (it->index >= numprops)
	  printf(" nnv%u, Index: %u, Occurrences: %u, Positive: %u, Negative : %u, hashval:%u", it->index - numprops, it->index, it->occurrences, it->positive_occurrences, it->negative_occurrences, it->hh_index.hashv);
	else 
	  printf(" %s, Index: %u, Occurrences: %u, Positive: %u, Negative : %u, hashval:%u", it->name, it->index, it->occurrences, it->positive_occurrences, it->negative_occurrences, it->hh_index.hashv);
	printf("\n Positive occurrences: ");
	positions *tmp = it->positive;
	while(tmp != NULL) {
	  printf("%p. ",tmp->pos);
	  tmp =tmp->next;
	}
	printf("\n Negative occurrences: ");
	tmp = it->negative;
	while(tmp != NULL) {
	  printf("%p. ",tmp->pos);
	  tmp =tmp->next;
	}
	printf("\n");
      }
      else {
	printf(" Constant symbol:");
	printf(" %s, Index: %u, Occurrences: %u, Positive: %u, Negative : %u, hashval:%u", it->name, it->index, it->occurrences, it->positive_occurrences, it->negative_occurrences, it->hh_index.hashv);
	printf("\n Occurrences: ");
	positions *tmp = it->constants;
	while(tmp != NULL) {
	  printf("%p. ",tmp->pos);
	  tmp =tmp->next;
	}
	printf("\n");
      }
    }
}



void st_print_prop(unsigned int index) {
  symbol_table *entry = NULL;
  
  HASH_FIND(hh_index,st_index,&index,sizeof(unsigned int),entry);
  if (entry->index >= numprops)
    printf("nnv%u",(entry->index) - numprops);
  else
    printf(entry->name);
}


unsigned int countprops(void) {
  symbol_table *st=NULL, *staux = NULL;
  unsigned int number = 0;
  
  HASH_ITER(hh_index,st_index,st,staux) {
    if (st != NULL) {
      if ((st->index != CTRUE) && (st->index != CFALSE) && (st->index != CSTART)) {
	if (st->occurrences != 0) number++;
      }
    }
  }
  return number;
}

void st_Delete(void){
  symbol_table *current, *tmp;

  HASH_ITER(hh_id,st_name,current,tmp) {
    HASH_DELETE(hh_id,st_name,current);
    // not freeing here, as both hash tables share the same entries.
  }

  HASH_ITER(hh_index,st_index,current,tmp) {
    if (current) {
      if (current->name != NULL)
	free(current->name);
      current->constants = free_positions(current->constants);
      current->positive = free_positions(current->positive);
      current->negative = free_positions(current->negative);
    }
    HASH_DELETE(hh_index,st_index,current);
    free(current);
    current = NULL;
  }

  HASH_CLEAR(hh_id,st_name);
  HASH_CLEAR(hh_index,st_index);
  free(st_name);
  free(st_index);
  st_name = NULL;
  
}


