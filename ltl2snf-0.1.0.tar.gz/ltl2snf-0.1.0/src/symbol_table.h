#include "uthash.h"

#define CONSTANT 0
#define PROP 1
#define MAX_INT 2147483646

typedef struct symbol_table symbol_table;
typedef struct positions positions;

/* I think we can do that better, for pure literal elimination, if we annotate the depth of the position at the syntactic tree */

struct positions {
  void *pos;
  positions *next;
};

struct symbol_table{
  char *name;
  unsigned int index;
  unsigned int positive_occurrences;
  unsigned int negative_occurrences;
  unsigned int occurrences;
  positions *constants;
  positions *positive;
  positions *negative;
  UT_hash_handle hh_id;
  UT_hash_handle hh_index;
};

unsigned int st_InsertEntry(char* s);
void st_Print(void);
void st_Delete(void);
void st_print_prop(unsigned int index);
symbol_table *find_prop(unsigned int index);
symbol_table *insert_prop_position(int polarity,symbol_table *entry, void *s);
symbol_table *delete_prop_position(symbol_table *entry, void *s);
symbol_table *insert_constant_position(symbol_table *entry, void *s);
symbol_table *insert_pnew_node (unsigned int id);
unsigned int countprops(void);

unsigned int hash_symbol (char *s);
