#include <stdio.h>
#include "symbol_table.h"
#include "tree.h"

extern int numsimp;
extern tree *replace_parent(tree *parent, tree *position);

tree *update_parent(tree *t) {
  if (t != NULL) {
    if (t->left != NULL) {
      t->left->parent = t;
    }
    if (t->right != NULL) {
      t->right->parent = t;
    }
    if (t->children != NULL) {
      t->children->parent = t;
      list *aux = t->children;
      while (aux != NULL) {
	aux->child->parent = t;
	aux = aux->next;
      }
    }
  }
  return t;
}

int in (tree *t1, list *l) {
  while (l != NULL) {
    if (t1->index == l->child->index && same_tree(t1,l->child))
      return 1;
    else l = l->next;
  }
  return 0;
}

int in_neg (tree *t1, list *l) {
  int result = 0;

  if (t1->op == NOT) {
    result = in(t1->left,l);
  }
  else {
    tree *parent = t1->parent;
    tree *aux = create_tree(NOT,t1,NULL,NULL);
    result = in(aux,l);
    t1->parent = parent;
    free(aux);
  }

  if (!result && t1->op == NEXT) {
    if (t1->left->op == NOT) {
      tree *aux = t1->left;
      t1->left = t1->left->left;
      t1->index = hash_tree(t1);
      result = in(t1,l);
      t1->left = aux;
      t1->index = hash_tree(t1);
    }
    else {
      tree *aux = create_tree(NOT,t1->left,NULL,NULL);
      t1->left = aux;
      aux->parent = t1;
      t1->index = hash_tree(t1);
      result = in(t1,l);
      aux = t1->left;
      t1->left = aux->left;
      t1->left->parent = t1;
      t1->index = hash_tree(t1);
      free(aux);
    }
  }

  return result;
}


list *flatten(list *s, int op) {
  list *aux = s->child->children;
  //  printf("\n flattening, %p, %p",aux,aux->parent);
  aux->child->parent = s->parent;
  while (aux->next != NULL) {
    aux->next->child->parent = s->parent;
    aux = aux->next;
  }
  aux->next = s->next;
  list *temp = s;
  s = s->child->children;
  free(temp);
  numsimp++;
  sort_formulalist(op,&(s));
  s->index = hash_list(s);
  return s;
}


list *simplify_list(list *l, unsigned int operator) {
  if (l == NULL)
    return NULL;
  else {
    if (l->child->op == operator) {
      l = flatten(l, operator);
      l->index = hash_list(l);
      l = simplify_list(l,operator);
    }
    else {
      l->next = simplify_list(l->next, operator);
      if (in_neg(l->child,l->next)) {
	l->next = delete_list(l->next);
	l->child->left = delete_tree(l->child->left);
	l->child->right = delete_tree(l->child->right);
	list *aux = l->child->children;
	while (aux != NULL) {
	  aux->child = delete_tree(aux->child);
	  list *tmp = aux;
	  aux = aux->next;
	  free(tmp);
	}
	if (l->child->op == PROP) {
	  symbol_table *entry = find_prop(l->child->index);
	  entry = delete_prop_position(entry,l->child);
	}
	l->child->op = CONSTANT; 
	if (operator == AND)
	  l->child->index = CFALSE;
	else l->child->index = CTRUE;
	symbol_table *entry = find_prop(l->child->index);
	entry = insert_constant_position(entry,l->child);
	numsimp++;
      }
      else if (in(l->child,l->next)) {
	l->child = delete_tree(l->child);
	list *tmp = l->next;
	free(l);
	l = tmp;
	numsimp++;
      }
    }
  }
  sort_formulalist(operator,&l);
  l->index = hash_list(l);
  return l;
}


tree *get_simp(tree *node, int polarity, int option) {
  if (node == NULL) return node;
  else {
    node->polarity = polarity;
    switch(node->op) {
    case PROP:
    case CONSTANT:
      {
	return node;
      }
      break;
    case NOT:
      {
	if (node->left->op == NOT) {
	  node->left = replace_parent(node->left,node->left->left);
	  node = replace_parent(node,node->left);
	  node = get_simp(node,polarity,option);
	}
	else if (node->left->op == CONSTANT) {
	  node->op = CONSTANT;
	  if (node->left->index == CTRUE)
	    node->index = CFALSE;
	  else node->index = CTRUE;
	  node->left = delete_tree(node->left);
	  symbol_table *entry = find_prop(node->index);
	  entry = insert_constant_position(entry,node);
	  node = get_simp(node,polarity,option);
	}
      else node->left = get_simp(node->left,-polarity,option);
      }
      break;
    case NEXT:
      {
	if (node->left->op == ALWAYS) {
	  node->op = ALWAYS;
	  node->left->op = NEXT;
	  node->left->index = hash_tree(node->left);
	  node->index = hash_tree(node);
	}
	node->left = get_simp(node->left,polarity,option);
      }
      break;
    case AND:
    case OR:
      {
	
	list *aux = node->children;
	while (aux != NULL) {
	  aux->child = get_simp(aux->child,polarity,option);
	  aux = aux->next;
	}
	node->children = simplify_list(node->children,node->op);
	if (node->children->next == NULL) {
	  node = replace_parent(node,node->children->child);
	  numsimp++;
	}
      }
      break;
    case IMPLY:
      {
	node->left = get_simp(node->left,-polarity,option);
	node->right = get_simp(node->right,polarity,option);
	if (same_tree(node->left,node->right)) {
	  node->op = CONSTANT;
	  node->index = CTRUE;
	  node->left = delete_tree(node->left);
	  node->right = delete_tree(node->right);
	  symbol_table *entry = find_prop(node->index);
	  entry = insert_constant_position(entry,node);
	  numsimp++;
	}
      }
      break;
    case UNTIL:
      {
	node->left = get_simp(node->left,polarity,option);
	node->right = get_simp(node->right,polarity,option);
	if (same_tree(node->left,node->right)) {
	  node = replace_parent(node,node->right);
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
	else if ((node->right->op == NOT && same_tree(node->left,node->right->left)) ||
		 (node->left->op == NOT && same_tree(node->left->left,node->right))) {
	  node->op = SOMETIME;
	  node->left = delete_tree(node->left);
	  node->left = node->right;
	  node->right = NULL;
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
	else if (node->right->op == SOMETIME) {
	  node = replace_parent(node,node->right);
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
      }
      break;
    case UNLESS:
      {
	node->left = get_simp(node->left,polarity,option);
	node->right = get_simp(node->right,polarity,option);

	if (same_tree(node->left,node->right)) {
	  node = replace_parent(node,node->right);
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
	else if ((node->right->op == NOT && same_tree(node->left,node->right->left)) ||
		 (node->left->op == NOT && same_tree(node->left->left,node->right))) {
	  node->op = CONSTANT;
	  node->index = CTRUE;
	  node->left = delete_tree(node->left);
	  node->right = delete_tree(node->right);
	  symbol_table *entry = find_prop(node->index);
	  entry = insert_constant_position(entry,node);
	  numsimp++;
	}
	else if (node->left->op == ALWAYS) {
	  node->op = OR;
	  node->children = tree_to_list(node->left,node->right,OR);
	  node->index = hash_tree(node);
	  node->left = NULL;
	  node->right = NULL;
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
      }
      break;
    case SOMETIME:
      {
	node->left = get_simp(node->left,polarity,option);

	if ((node->left->op == SOMETIME) || (node->left->op == ALWAYS && node->left->left->op == SOMETIME)) {
	  node = replace_parent(node,node->left);
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
	else if (node->left->op == UNTIL) {
	  node->left->left = delete_tree(node->left->left);
	  node->left->op = SOMETIME;
	  node->left->left = node->left->right;
	  node->left->right = NULL;
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
      }
      break;
    case ALWAYS:
      {
	node->left = get_simp(node->left,polarity,option);
	if ((node->left->op == ALWAYS)  || (node->left->op == SOMETIME && node->left->left->op == ALWAYS)) {
	  node = replace_parent(node,node->left);
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
	else if (node->left->op == UNLESS) {
	  node->left->op = OR;
	  node->left->children = tree_to_list(node->left->left,node->left->right,OR);
	  node->index = hash_tree(node);
	  node->left->left = NULL;
	  node->left->right = NULL;
	  node = get_simp(node,polarity,option);
	  numsimp++;
	}
      }
      break;
    }
  }
  node = update_parent(node);
  node->index = hash_tree(node);
  return node;
}
