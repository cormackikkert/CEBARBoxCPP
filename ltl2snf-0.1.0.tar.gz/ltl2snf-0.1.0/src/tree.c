#include <stdlib.h>
#include <stdio.h>
#include "tree.h"
#include "symbol_table.h"
#include "uthash.h"

/* Tree Functions */

int indentation = 1;
int tab = 4;

extern void st_print_prop(unsigned int i);


int same_tree (tree *t1, tree *t2);
int same_list(list *l1, list *l2) {
  if (l1 == NULL) {
    if (l2 == NULL) {
      return 1;
    }
  }
  else if (l2 == NULL) 
    return 0;
  else if (same_tree(l1->child,l2->child))
    return (same_list(l1->next,l2->next));
  return 0;
}

int same_tree (tree *t1, tree *t2) {
  if (t1 == NULL) {
    if (t2 == NULL) {
      return 1;
    }
  }
  else if (t2 == NULL) 
    return 0;
  else if (t1->op == t2->op && t1->index == t2->index && same_list(t1->children,t2->children))
    return (same_tree(t1->left,t2->left) && same_tree(t1->right,t2->right));
  return 0;
}


tree* new_tree(void) {
	tree *t = malloc(sizeof(tree));
	if (!t) {printf("Out of Memory\n"); exit(1);}
	t->op = 0;
	t->index = 0;
	t->polarity = 0;
	t->left = NULL;
	t->right = NULL;
	t->children = NULL;
	t->parent = NULL;
	return t;
}

tree* tree_op(tree *t, unsigned int op) {
	t->op = op;
	return t;
}

tree* tree_children(tree *t, tree *left, tree *right, list *children) {

  t->left = left;
  t->right = right;
  t->children = children;
  if (t->left != NULL)
    left->parent = t;
  if (t->right != NULL)
    right->parent = t;
  list *tmp = children;
  while (tmp != NULL) {
    tmp->child->parent = t;
    tmp = tmp->next;
  }
  hash_tree(t);
  return t;
}

tree* create_tree(unsigned int op, tree *left, tree *right, list *children) {
  tree * t = new_tree();
  t = tree_op(t,op);
  t = tree_children(t,left,right,children);
  return t;
}


list *delete_list(list *l) {
  while(l != NULL) {
    l->child = delete_tree(l->child);
    list *tmp = l;
    l = l->next;
    free(tmp);
  }
  return NULL;
}

tree* delete_tree(tree *t) {
  if (t != NULL) {
    if (t->op == CONSTANT) {
      symbol_table *entry = find_prop(t->index);
      if (entry != NULL) {
	positions *l = entry->constants;
	while (l != NULL && l->pos != t) {
	  l = l->next;
	}
	if (l != NULL){
	  if (l->pos == t) {
	    l->pos = NULL;
	  }
	}
      }
    }
    if (t-> op == PROP) {
      symbol_table *entry = find_prop(t->index);
      entry = delete_prop_position(entry,t);
    }
    else {
      t->left = delete_tree(t->left);
      t->right = delete_tree(t->right);
      t->children = delete_list(t->children);
    }
    free(t);
  }
  return NULL;
}



list *sorted_merge_formulalist(int type, list *left, list *right) {
  list *result = NULL;
  if (left == NULL)
    return right;
  else if (right == NULL)
    return left;
  if (left->child->op < right->child->op)  {
    result = left;
    result->next = sorted_merge_formulalist(type,left->next,right);
  }
  else if (left->child->op == right->child->op && left->child->index <= right->child->index)  {
    result = left;
    result->next = sorted_merge_formulalist(type,left->next,right);
  }
  else {
    result = right;
    result->next = sorted_merge_formulalist(type,left,right->next);
  }
  return result;
}


void split_formulalist(list *l, list **left, list **right) {
  list *fast;
  list *slow;

  if (l == NULL || l->next == NULL) {
    *left = l;
    *right = NULL;
  }
  else {
    slow = l;
    fast = l->next;
    while (fast != NULL) {
      fast = fast->next;
      if (fast != NULL) {
	slow = slow->next;
	fast = fast->next;
      }
    }
    *left = l;
    *right = slow->next;
    slow->next = NULL;
  }
}


void sort_formulalist(int type, list **l) {
  list *head = *l;
  list *left;
  list *right;
  
  if (head == NULL || head->next == NULL)
    return;
  else {
    split_formulalist(head,&left,&right);
    sort_formulalist(type,&left);
    sort_formulalist(type,&right);
    *l = sorted_merge_formulalist(type,left,right);
  }
}


list *tree_to_list(tree *t1, tree *t2, unsigned int op) {
  list *l1 = NULL,*l2 = NULL;
  if (t1->op == op) {
    l1 = t1->children;
    free(t1);
  }
  else {
    l1 = malloc(sizeof(list));
    if (l1 == NULL) {printf("Out of Memory\n"); exit(1);}
    l1->child = t1;
    l1->next = NULL;
  }
  if (t2 != NULL) {
    if (t2->op == op) {
      l2 = t2->children;
      free(t2);
    }
    else {
      l2 = malloc(sizeof(list));
      if (l2 == NULL) {printf("Out of Memory\n"); exit(1);}
      l2->child = t2;
      l2->next = NULL;
    }
  }
  return sorted_merge_formulalist(op,l1,l2);
}


tree *copy_tree(tree *s, int option);
list *copy_list(list *s, int option) {
  if (s == NULL) return NULL;
  else {
    list *l = malloc(sizeof(list));
    if (l == NULL) {printf("Out of Memory\n"); exit(1);}
    l->child = copy_tree(s->child, option);
    l->next = copy_list(s->next,option);
    return l;
  }
}

tree *copy_tree(tree *s, int option) {
  if (s == NULL) return NULL;
  else {
    tree *new = malloc(sizeof(tree));
    if (new == NULL) {printf("Out of Memory\n"); exit(1);}
    
    new->op = s->op;
    new->index = s->index;
    new->polarity = s->polarity;
    new->parent = s->parent;
    new->left = copy_tree(s->left,option);
    new->right = copy_tree(s->right,option);
    new->children = copy_list(s->children,option);

    if ((s->op == PROP) & option) {
      symbol_table *entry = find_prop(s->index);
      entry->occurrences++;
      entry = insert_prop_position(s->polarity,entry,new);
    }
    if ((s->op == CONSTANT) & option) {
      symbol_table *entry = find_prop(s->index);
      entry = insert_constant_position(entry,new);
    }
    return new;
  }
}


tree *copy_node(tree *s1, tree *s2) {
  if (s2 == NULL) return NULL;
  else {
    s1->op = s2->op;
    if (s2->op == PROP) {
      symbol_table *entry = find_prop(s2->index);
      insert_prop_position(s2->polarity,entry,s1);
      entry->occurrences++;
    }
    if (s2->op == CONSTANT) {
      symbol_table *entry = find_prop(s2->index);
      insert_constant_position(entry,s1);
    }
    s1->index = s2->index;
    s1->polarity = s2->polarity;
    s1->left = s2->left;
    s1->right = s2->right;
    s1->children = s2->children;
    s1->parent = s2->parent;
    return s1;
  }
}


int print_list(list *l) {
  if (l == NULL)
    return 0;
  int size1 = print_tree(l->child);
  return (size1 + print_list(l->next));
}


int print_tree(tree *s) {  
  int i;
  int size1, size2;
  
  if (s!=NULL) {
    for (i=0;i<indentation;i++) printf(" ");
  
    switch (s->op) {
    case CONSTANT:
      if (s->index == CTRUE) printf("TRUE (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      else if (s->index == CFALSE) printf("FALSE (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      return 1;
      break;
    case PROP: 
      printf("PROPOSITION: ");
      st_print_prop(s->index);
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      return 1;
      break;
    case NOT: 
      printf("NEGATION");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      indentation -= tab;
      return size1 + 1;
      break;
    case NEXT: 
      printf("NEXT");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      indentation -= tab;
      return size1 + 1;
      break;
    case ALWAYS: 
      printf("ALWAYS");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      indentation -= tab;
      return size1 + 1;
      break;
    case SOMETIME: 
      printf("SOMETIME");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      indentation -= tab;
      return size1 + 1;
      break;
    case AND:
      printf("CONJUNCTION");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_list(s->children);
      indentation -= tab;
      return size1 + 1;
      break;
    case OR:
      printf("DISJUNCTION");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_list(s->children);
      indentation -= tab;
      return size1 + 1;
      break;
    case UNTIL:
      printf("UNTIL");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      size2 = print_tree(s->right);
      indentation -= tab;
      return size1 + size2 + 1;
      break;
    case UNLESS:
      printf("UNLESS");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      size2 = print_tree(s->right);
      indentation -= tab;
      return size1 + size2 + 1;
      break;
    case IMPLY:
      printf("IMPLICATION");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      size2 = print_tree(s->right);
      indentation -= tab;
      return size1 + size2 + 1;
      break;
    case IFF:
      printf("DOUBLE IMPLICATION");
      printf(" (index:%u,pol:%d,pos:%p",s->index,s->polarity,s);
      if (s->parent != NULL)
	printf(",parent position:%p)\n", s->parent);
      else printf(")\n");
      indentation += tab;
      size1 = print_tree(s->left);
      size2 = print_tree(s->right);
      indentation -= tab;
      return size1 + size2 + 1;
      break;
    default:
      printf("Operator not found while printing the syntactic tree. %p, %u\n",s,s->op);
    }
  }
  return 0;
}


unsigned int hash_list (list *l) {
  unsigned int value = 0;
  list *aux = l;
  while (aux != NULL) {
    if (aux->child != NULL)
      value = 31*value + aux->child->index;
    aux = aux->next;
  }
  return value;
}

unsigned int hash_tree (tree *t) {
  if (!(t->op == PROP || t->op == CONSTANT)){
    HASH_JEN(&(t->op),sizeof(int),t->index);
    if (t->left != NULL) 
      t->index = 31*t->index + t->left->index;
    if (t->right != NULL) 
      t->index = 31*t->index + t->right->index;
    if (t->children != NULL)
      {
	t->children->index = hash_list(t->children);
	t->index = 31*t->index + t->children->index;
      }
  }
  return t->index;
}



