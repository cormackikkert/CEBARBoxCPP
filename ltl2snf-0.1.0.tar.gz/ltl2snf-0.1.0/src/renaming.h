#ifndef RENAMING_H
#define RENAMING_H 

#endif //RENAMING_H

typedef struct {
  int operator;
  unsigned int index;
} ren_key;

typedef struct ren_hash {
  ren_key key;
  list *list;
  UT_hash_handle hren;
} ren_hash;

unsigned int add_renaming (unsigned int index, tree *formula, list **l);
unsigned int rename_formula(tree *formula, list **l);


