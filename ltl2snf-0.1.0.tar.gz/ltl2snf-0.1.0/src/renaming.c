#include <stdio.h>
#include "uthash.h"
#include "tree.h"
#include "symbol_table.h"
#include "renaming.h"

extern unsigned int strong_renaming;
extern unsigned int reuse_renaming;
extern unsigned int normal_renaming;
extern unsigned int numtemp;

extern tree *get_nnf(tree *s, int polarity, int stat);
extern tree *get_snf(tree *formula);

ren_hash *renaming_table = NULL;

tree *tree_hash(tree *s);

list *list_hash(list *l) {
  if (l != NULL) {
    unsigned int value = 0;
    list *aux = l;
    while (aux != NULL) {
      value = 31*value + aux->child->index;
      aux = aux->next;
    }
  }
  return l;
}

tree *tree_hash(tree *t) {
  if (t != NULL) {
    HASH_JEN(&(t->op),sizeof(int),t->index);
    if (t->op != PROP && t->op != CONSTANT) {
      if (t->left != NULL) 
	t->index = 31*t->index + t->left->index;
      if (t->right != NULL) 
	t->index = 31*t->index + t->right->index;
      if (t->children != NULL) 
	t->index = 31*t->index + t->children->index;
    }
  }
  return t;
}


void add_definition(unsigned int id, tree *formula,list **def) {
  symbol_table *p;

  /*
  if (id < 0)
    p = find_prop(-id);
  else p = find_prop(id);
  */

  p = find_prop(id);
  tree *left = create_tree(PROP,NULL,NULL,NULL);
  left->index = p->index;
  /*if (id < 0) {
    tree *not = create_tree(NOT,left,NULL,NULL);
    left = not;
    }*/
  tree *imply = create_tree(IMPLY,left,formula,NULL);
  tree *always = create_tree(ALWAYS,imply,NULL,NULL);
  list *new = malloc(sizeof(list));
  if (new == NULL) {printf("Out of Memory\n"); exit(1);}
  new->child = always;
  new->next = *def;
  *def = new;
  //  newimp = get_snf(newimp);
  //  free(left);
  //free(newimp);
}

unsigned int add_renaming (unsigned int index, tree *formula, list **l) {

  ren_hash *c;
  ren_key key;

  unsigned int found = 0;
  
  key.operator = formula->op;
  key.index = formula->index;
  
  HASH_FIND(hren,renaming_table,&(key),sizeof(ren_key),c);
    
  if (c != NULL) {
    list *aux = c->list;
    while (!found && aux != NULL) {
      if (same_tree(formula,aux->child)) {
	found = 1;
      }
      else aux = aux->next;
    }
    if (!found) {
      list *new_list = malloc(sizeof(list));
      if (new_list == NULL) {printf("Out of Memory\n"); exit(1);}
      new_list->index = formula->index;
      new_list->renamed_by = index;
      new_list->definition_added = 0;
      //new_list->child = NULL;
      new_list->child = copy_tree(formula,0);
      //new_list->child = tree_hash(new_list->child);
      new_list->next = c->list;
      c->list = new_list;
      if (strong_renaming) {
	tree *neg = copy_tree(formula,0);
	tree *not = create_tree(NOT,neg,NULL,NULL);
	not = get_nnf(not,formula->polarity,1);
	not = tree_hash(not);
	add_renaming(-index,not,l);
	not = delete_tree(not);
      }
    }
  }
  else {
    ren_hash *new = malloc(sizeof(ren_hash));
    if (new  == NULL) {printf("Out of Memory\n"); exit(1);}
    new->list = NULL;
    
    ren_key new_key;
    new_key.operator = formula->op;
    new_key.index = formula->index;

    new->key = new_key;

    list *new_list = malloc(sizeof(list));
    if (new_list  == NULL) {printf("Out of Memory\n"); exit(1);}

    new_list->index = formula->index;
    new_list->renamed_by = index;
    new_list->definition_added = 0;
    //new_list->child = NULL;
    new_list->child = copy_tree(formula,0);
    //new_list->child = tree_hash(new_list->child);
    new_list->next = new->list;
    new->list = new_list;
    HASH_ADD(hren,renaming_table,key,sizeof(ren_key),new);
    if (strong_renaming) {
      tree *neg = copy_tree(formula,0);
      tree *not = create_tree(NOT,neg,NULL,NULL);
      not = get_nnf(not,formula->polarity,1);
      not = tree_hash(not);
      add_renaming(-index,not,l);
      not = delete_tree(not);
    }
  }
  return found;
}

unsigned int insert_renaming_table(ren_key key, tree *formula, list **l) {
  ren_hash *c = NULL;
  HASH_FIND(hren,renaming_table,&(key),sizeof(ren_key),c);
  if (c != NULL) {
    list *aux = c->list;
    while (aux != NULL) {
      if (same_tree(formula,aux->child)) {
	if (!aux->definition_added) {
	  add_definition(aux->renamed_by,aux->child,l);
	  aux->definition_added = 1;
	}
	return aux->renamed_by;
      }
      else aux = aux->next;
    }
    
    symbol_table *p = insert_pnew_node(numtemp++);
    list *new_list = malloc(sizeof(list));
    if (new_list == NULL) {printf("Out of Memory\n"); exit(1);}

    new_list->index = formula->index;
    new_list->child = copy_tree(formula,0);
    new_list->next = c->list;
    c->list = new_list;
    new_list->renamed_by = p->index;
    new_list->definition_added = 1;
    add_definition(p->index,formula,l);
    return p->index;
  }
  else {
    ren_hash *new = malloc(sizeof(ren_hash));
    if (new  == NULL) {printf("Out of Memory\n"); exit(1);}
    new->list = NULL;
    
    ren_key new_key;
    new_key.operator = key.operator;
    new_key.index = key.index;

    new->key = new_key;

    symbol_table *p = insert_pnew_node(numtemp++);
    
    list *new_list = malloc(sizeof(list));
    if (new_list  == NULL) {printf("Out of Memory\n"); exit(1);}

    new_list->index = formula->index;
    new_list->renamed_by = p->index;
    new_list->definition_added = 1;
    new_list->child = copy_tree(formula,0);
    new_list->next = new->list;
    new->list = new_list;

    HASH_ADD(hren,renaming_table,key,sizeof(ren_key),new);
    add_definition(p->index,formula,l);
    return p->index;
  }
}

unsigned int rename_formula(tree *oformula, list **l) {
  unsigned int id = 0;

  tree *formula = copy_tree(oformula,1);
  if (normal_renaming) {
    symbol_table *p = insert_pnew_node(numtemp++);
    //    printf("\n p->index: %u",p->index);
    add_definition(p->index,formula,l);
    return p->index;
  }
  else {
    ren_key key;  
    key.operator = formula->op;
    key.index = formula->index;
    
    id = insert_renaming_table(key,formula,l);

    if (strong_renaming) {
      tree *neg = copy_tree(formula,0);
      tree *not = create_tree(NOT,neg,NULL,NULL);
      not = get_nnf(not,formula->polarity,1);
      not = tree_hash(not);
      add_renaming(-id,not,l);
      not = delete_tree(not);
    }
    return id;
  }
}

void print_ren_hash(void) {
  ren_hash *tmp,*tmpp;
  printf("\n HASH TABLE\n");
  HASH_ITER(hren,renaming_table,tmp,tmpp) {
    printf("\n Operator: %d, Index: %u",tmp->key.operator,tmp->key.index);
    list *aux = tmp->list;
    while (aux != NULL) {
      printf("\n Renamed by: %u\n",aux->renamed_by);
      print_tree(aux->child); 
      aux = aux->next;
    }
  }
}

void clean_ren_hash(void) {
  ren_hash *tmp,*tmpp;
  
 HASH_ITER(hren,renaming_table,tmp,tmpp) {
   HASH_DELETE(hren,renaming_table,tmp);
   if (tmp != NULL) {
     list *aux = tmp->list;
     while (aux != NULL) {
       aux->child = delete_tree(aux->child);
       list *aux2 = aux->next;
       free(aux);
       aux = aux2; 
     }
     free(tmp);
   }
 }
 HASH_CLEAR(hren,renaming_table);
 renaming_table = NULL;
}
