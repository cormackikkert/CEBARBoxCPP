#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "symbol_table.h"
#include "tree.h"
#include "renaming.h"
#include "snf.h"
#include "parser.tab.h"
#include "output.h"

#define ON 1
#define OFF 0

extern symbol_table *st;
extern unsigned int numprops;
extern unsigned int numtemp;
extern unsigned int improved_snf;

extern int print_list(list *l);
extern list *simplify_list(list *l, unsigned int operator);
extern tree *replace_parent(tree *parent, tree *position);
list *clauses = NULL;


tree *create_clause(tree *left,unsigned int op,tree *right) {
  tree *nleft = copy_tree(left,1);
  tree *nright = copy_tree(right,1);

  if (op == NEXT || op == SOMETIME) {
    tree *next = create_tree(op,nright,NULL,NULL);
    nright = next;
  }
  tree *imply = create_tree(IMPLY,nleft,nright,NULL);
  tree *always = create_tree(ALWAYS,imply,NULL,NULL);

  return always;
}

tree *remove_clause_list(list **l) {
  list *aux_l = *l;
  list *aux_first = aux_l;
  tree *aux_t = aux_l->child;
  aux_l = aux_l->next;
  *l = aux_l;
  free(aux_first);
  return aux_t;
}

list *insert_clause_list(tree* t, list *l) {
  list *newl = malloc(sizeof(list));
  if (newl == NULL) {printf("Out of Memory\n"); exit(1);}
  newl->child = t;
  newl->next = l;
  l = newl;
  return l;
}

list *move_clause_list(list **el1, list *l2) {
  list *l1 = *el1;
  list *aux = l1->next;
  l1->next = l2;
  l2 = l1;
  *el1 = aux;
  return l2;
}



tree *hash(tree *t) {
  if (t != NULL) {
    if (t->op != PROP && t->op != CONSTANT) {
      HASH_JEN(&(t->op),sizeof(int),t->index);
      if (t->left != NULL) {
	t->left = hash(t->left);
	t->index = 31*t->index + t->left->index;
      }
      if (t->right != NULL) {
	t->right = hash(t->right);
	t->index = 31*t->index + t->right->index;
      }
      if (t->children != NULL) {
	list *l= t->children;
	int value = 0;
	while (l != NULL) {
	  l->child = hash(l->child);
	  value = 31*value + l->child->index;
	  l = l->next;
	}
	t->children->index = value;
	t->index = 31*t->index + t->children->index;
      }
    }
  }
  return t;
}

int is_literal(tree *formula) {
  return (formula->op == PROP || (formula->op == NOT && is_literal(formula->left)) || formula->op == CONSTANT  );
}

int is_next_literal(tree *formula) {
  return (formula->op == NEXT && is_literal(formula->left));
}

int is_disjunction_literal_next(tree* formula) {
  if (is_literal(formula) || is_next_literal(formula))
    return 1;
  int flag = (formula->op == OR);
  if (flag) {
    list *aux = formula->children;
    while (flag && aux != NULL) {
      flag = (is_literal(aux->child) || is_next_literal(aux->child));
      aux = aux->next;
    }
  }
  return flag;
}

int is_sometime_clause(tree *formula) {
  return (formula->op == SOMETIME && is_literal(formula->left));
}


int is_clause(tree *formula) {
  return (is_literal(formula) || is_disjunction_literal_next(formula));
}


int in_form(tree *formula) {
  if (is_clause (formula))
    return 1;
  if (formula->op == ALWAYS && formula->left->op == IMPLY) {
    formula = formula->left->right;
    return (is_clause(formula) || is_sometime_clause(formula));
  }
  return 0;
}

list *simplify_constants_clause(list *l) {
  list *aux = l;
  while(aux != NULL) {
    if ((aux->child->op == SOMETIME && aux->child->left->op == CONSTANT) ||
	(aux->child->op == NEXT && aux->child->left->op == CONSTANT)) {
      tree *aux_t = aux->child;
      aux->child = aux->child->left;
      aux->child->left = NULL;
      free(aux_t);
    }
    aux = aux->next;
  }
  return l;
}

list *remove_constants_clause(list *l) {
  //  printf("\n Before removal \n");
  //  print_list(l);
  list *aux = l;
  if (aux->child->op == CONSTANT && aux->child->index == CTRUE) {
    aux->next = NULL; // delete_list(aux->next);
  }
  else while (aux != NULL && aux->child->op == CONSTANT && aux->child->index == CFALSE) {
      if (aux->next != NULL) {
	aux->child = delete_tree(aux->child);
	list *tmp = aux->next;
	free(aux);
	aux = tmp;
      }
    }
  //  printf("\n After removal \n");
  //  print_list(l);
  
  return aux;
}


list *get_disjunctions(list *d) {
  list *first = d;
  while (d != NULL) {
    //    printf("\n Before\n");
    //    print_tree(d->child);
    tree *formula = d->child;
    if (formula->op == CONSTANT || formula->op == PROP) { // it is an initial clause
      tree *new = copy_tree(formula,1);
      formula->children = malloc(sizeof(list));
      formula->children->child = new;
      formula->children->next = NULL;
      formula->op = OR;
    }
    else if(formula->op == ALWAYS && formula->left->op == IMPLY) {
      tree *cformula = formula->left;
      if ((cformula->left->op == CONSTANT && cformula->left->index == CTRUE)) { // it is a clause of the form true => phi)
	cformula->left = delete_tree(cformula->left);
	cformula->children = tree_to_list(cformula->right,NULL,OR);
	cformula->right = NULL;
	cformula->op = OR;
      }
      else { // we remove the implication
	cformula->op = OR;
	tree *left = create_tree(NOT,cformula->left,NULL,NULL);
	cformula->children = tree_to_list(left,cformula->right,OR);
	cformula->left = NULL;
	cformula->right = NULL;
      }
      cformula->children = simplify_constants_clause(cformula->children);
      cformula->children = simplify_list(cformula->children,OR);
      sort_formulalist(OR,&(cformula->children));
      cformula->children = remove_constants_clause(cformula->children);
    }
    //    printf("\n After\n");
    //    print_tree(d->child);
    
    d = d->next;
  }
  return first;
}

int check_clause(tree *c) {
  int flag = 1;
  if (c->op != ALWAYS) {
    printf("\n Error in SNF. Expecting [] phi, got formula->op %u\n", c->op);
    //    print_tree(c); 
    flag = 0;
  }
  else if (c->left->op != IMPLY) {
    printf("\n Error in SNF. Expecting phi => psi, got formula->op %u", c->left->op);
    flag = 0;
  }
  return flag;
}

list *get_snf_list(list *d) {

  list *first = d;
  while (d != NULL) {
    if (in_form(d->child)) {
      //      printf("\n IN FORM:");print_tree(d->child);
      clauses = move_clause_list(&d,clauses);
    }
    else {
      tree *c = remove_clause_list(&d);
      if (check_clause(c)) {
	tree* cformula = c->left;
	
	if (improved_snf == ON &&
	    cformula->left->op == PROP &&
	    cformula->left->index == numprops &&
	    cformula->right->op == ALWAYS) { 	    // [](t0 => []phi) --> []phi

	  //	  printf("\n ISNF:");print_tree(cformula);printf("\n");
	  cformula->right = replace_parent(cformula->right,cformula->right->left);
	  cformula->left = NULL;//delete_tree(cformula->left);
	  cformula->left = create_tree(CONSTANT,NULL,NULL,NULL);
	  cformula->left->index = CTRUE;
	  cformula->left->parent = cformula;
	  d = insert_clause_list(c,d);
	}
	else {
	  tree *formula = cformula->right;
	  switch(formula->op) {
	  case NOT:
	  case PROP:
	  case CONSTANT:
	    {
	      clauses = insert_clause_list(c,clauses);
	      printf("\n It shouldn't be here because this is already in form.");
	    }
	    break;
	  case AND:
	    {
	      list *aux = formula->children;
	      while (aux != NULL) {
		tree *clause = create_clause(cformula->left,-1,aux->child);
		d = insert_clause_list(clause,d);
		aux = aux->next;
	      }
	    }
	    break;
	  case SOMETIME:
	  case NEXT:
	      {
		tree *clause = NULL;
		if (!is_literal(formula->left)) {
		  unsigned int index = rename_formula(formula->left,&d);
		  tree *p_node = create_tree(PROP,NULL,NULL,NULL);
		  p_node->index = index;
		  p_node->parent = formula;
		  clause = create_clause(cformula->left,formula->op,p_node);
		}
		else clause = copy_tree(c,1);
		clauses = insert_clause_list(clause,clauses);
	      }
	      break;
	    case OR:
	      {
		list *aux = formula->children;
		int counter_sometime = 0;
		int counter_next = 0;
		while (aux != NULL) {
		  if (aux->child->op == NEXT){
		    counter_next++;
		    if (!is_literal(aux->child->left)) {
		      unsigned int index = rename_formula(aux->child->left,&d);
		      aux->child->left->op = PROP;
		      aux->child->left->index = index;
		      aux->child->left->left = delete_tree(aux->child->left->left);
		      aux->child->left->right = delete_tree(aux->child->left->right);
		      aux->child->left->children = delete_list(aux->child->left->children);
		    }
		  }
		  aux = aux->next;
		}
		aux = formula->children;
		while (aux != NULL) {
		  if (counter_next == 0 && counter_sometime == 0 && aux->child->op == SOMETIME){
		    counter_sometime++;
		    if (!is_literal(aux->child->left)) {
		      unsigned int index = rename_formula(aux->child->left,&d);
		      aux->child->left->op = PROP;
		      aux->child->left->index = index;
		      aux->child->left->left = delete_tree(aux->child->left->left);
		      aux->child->left->right = delete_tree(aux->child->left->right);
		      aux->child->left->children = delete_list(aux->child->left->children);
		    }
		  }
		  else if (!is_literal(aux->child) && !is_next_literal(aux->child)) {
		    unsigned int index = rename_formula(aux->child,&d);
		    aux->child->op = PROP;
		    aux->child->index = index;
		    aux->child->left = delete_tree(aux->child->left);
		    aux->child->right = delete_tree(aux->child->right);
		    aux->child->children = delete_list(aux->child->children);
		  }
		  aux = aux->next;
		}
		tree *clause = copy_tree(c,1);
		clauses = insert_clause_list(clause,clauses);
	      }
	      break;
	    case ALWAYS:
	      {
		if (!(formula->left->op == OR) && !is_literal(formula->left)) {
		  unsigned int index = rename_formula(formula->left,&d);
		  formula->left->op = PROP;
		  formula->left->index = index;
		  formula->left->left = NULL;
		  formula->left->right = NULL;
		  formula->left->children = NULL;
		}
		else if (formula->left->op == OR) {
		  list *aux = formula->left->children;
		  int counter_sometime = 0;
		  int counter_next = 0;
		  while (aux != NULL) {
		    if (aux->child->op == NEXT){
		      counter_next++;
		      if (!is_literal(aux->child->left)) {
			unsigned int index = rename_formula(aux->child->left,&d);
			aux->child->left->op = PROP;
			aux->child->left->index = index;
			aux->child->left->left = NULL;
			aux->child->left->right = NULL;
			aux->child->left->children = NULL;
		      }
		    }
		    aux = aux->next;
		  }
		  aux = formula->left->children;
		  while (aux != NULL) {
		    if (counter_next == 0 && counter_sometime == 0 && aux->child->op == SOMETIME){
		      counter_sometime++;
		      if (!is_literal(aux->child->left)) {
			unsigned int index = rename_formula(aux->child->left,&d);
			aux->child->left->op = PROP;
			aux->child->left->index = index;
			aux->child->left->left = NULL;
			aux->child->left->right = NULL;
			aux->child->left->children = NULL;
		      }
		    }
		    else if (!is_literal(aux->child) && !is_next_literal(aux->child)) {
		      unsigned int index = rename_formula(aux->child,&d);
		      aux->child->op = PROP;
		      aux->child->index = index;
		      aux->child->left = NULL;
		      aux->child->right = NULL;
		      aux->child->children = NULL;
		    }
		    aux = aux->next;
		  }
		}

		symbol_table *p0 = insert_pnew_node(numtemp++);
		tree *p0_node = create_tree(PROP,NULL,NULL,NULL);
		p0_node->index = p0->index;
		p0_node->polarity = 1;

		tree *clause1 = create_clause(cformula->left,-1,formula->left);
		tree *clause2 = create_clause(cformula->left,-1,p0_node);
		tree *clause3 = create_clause(p0_node,NEXT,formula->left);
		tree *clause4 = create_clause(p0_node,NEXT,p0_node);

		clauses = insert_clause_list(clause1,clauses);
		clauses = insert_clause_list(clause2,clauses);
		d = insert_clause_list(clause3,d);
		clauses = insert_clause_list(clause4,clauses);
	      }
	      break;
	  case UNTIL:
	  case UNLESS:
	      {
		if (!is_literal(formula->left)) {
		  unsigned int index = rename_formula(formula->left,&d);
		  formula->left->op = PROP;
		  formula->left->index = index;
		  formula->left->left = NULL;
		  formula->left->right = NULL;
		  formula->left->children = NULL;
		  
		  
		}
		if (!is_literal(formula->right)) {
		  unsigned int index = rename_formula(formula->right,&d);
		  formula->right->op = PROP;
		  formula->right->index = index;
		  formula->right->left = NULL;
		  formula->right->right = NULL;
		  formula->right->children = NULL;
		  
		}

		symbol_table *p0 = insert_pnew_node(numtemp++);
		tree *p0_node = create_tree(PROP,NULL,NULL,NULL);
		p0_node->index = p0->index;
		p0_node->polarity = 1;


	        if (formula->op == UNTIL) {
		  tree *clause1 = create_clause(cformula->left,SOMETIME,formula->right);
		  clauses = insert_clause_list(clause1,clauses);
		}

		list *lor1 = tree_to_list(formula->left,formula->right,OR);
		tree *tor1 = create_tree(OR,NULL,NULL,lor1);
		
		tree *clause2 = create_clause(cformula->left,-1,tor1);

		list *lor2 = tree_to_list(p0_node,formula->right,OR);
		tree *tor2 = create_tree(OR,NULL,NULL,lor2);
		
		tree *clause3 = create_clause(cformula->left,-1,tor2);

		tree *ntor1 = create_tree(NEXT,tor1->children->child,NULL,NULL);
		tree *ntor2 = create_tree(NEXT,tor1->children->next->child,NULL,NULL);
		tor1->children->child = ntor1;
		tor1->children->next->child = ntor2;
		
		tree *clause4 = create_clause(p0_node,-1,tor1);

		tree *ntor3 = create_tree(NEXT,tor2->children->child,NULL,NULL);
		tree *ntor4 = create_tree(NEXT,tor2->children->next->child,NULL,NULL);
		tor2->children->child = ntor3;
		tor2->children->next->child = ntor4;

		tree *clause5 = create_clause(p0_node,-1,tor2);
		
		p0_node = delete_tree(p0_node);
		free(lor1);
		free(lor2);
		free(ntor1);
		free(ntor2);
		free(ntor3);
		free(ntor4);

		clauses = insert_clause_list(clause2,clauses);
		clauses = insert_clause_list(clause3,clauses);
		clauses = insert_clause_list(clause4,clauses);
		clauses = insert_clause_list(clause5,clauses);
	      }
	      break;
	    default: printf("\n Unknown operator, SNF, %u",formula->op);
	  }
	}
      }
    }
  }
  return first;
}

tree *get_snf(tree *formula) {
  if (formula == NULL)
    return NULL;
  else if (formula->op == CONSTANT) {
    symbol_table *p0 = insert_pnew_node(numprops);
    tree *p0_node = create_tree(PROP,NULL,NULL,NULL);
    p0_node->index = p0->index;
    p0_node->polarity = 1;
    list *orlist = tree_to_list(p0_node,NULL,OR);
    tree *or = create_tree(OR,NULL,NULL,orlist);
    clauses = malloc(sizeof(list));
    if (!clauses) {printf("Out of Memory\n"); exit(1);}
    clauses->child = or;
    clauses->next = NULL;
    if (formula->index == CFALSE) {
      tree *p0_copy = copy_tree(p0_node,1);
      tree *not = create_tree(NOT,p0_copy,NULL,NULL);
      list *orlist = tree_to_list(not,NULL,OR);
      tree *or = create_tree(OR,NULL,NULL,orlist);
      tree *always = create_tree(ALWAYS,or,NULL,NULL);
      clauses->next = malloc(sizeof(list));
      if (!(clauses->next)) {printf("Out of Memory\n"); exit(1);}
      clauses->next->child = always;
      clauses->next->next = NULL;
    }
    tree *and = create_tree(AND,NULL,NULL,clauses);
    return and;
  }
  else {
    formula = hash(formula);
   
    symbol_table *p0 = insert_pnew_node(numprops);
    tree *p0_node = create_tree(PROP,NULL,NULL,NULL);
    p0_node->index = p0->index;
    p0_node->polarity = 1;

    clauses = insert_clause_list(p0_node,clauses);

    list *formulas = NULL;
    tree *clause = create_clause(p0_node,-1,formula);
    formulas = insert_clause_list(clause,formulas);
    
    formulas = get_snf_list(formulas);
    //    print_list(clauses);printf("\n\n");
    clauses = get_disjunctions(clauses);
    //    print_list(clauses);

    tree *and = create_tree(AND,NULL,NULL,clauses);
    return and;
  }
}

